package model

data class Port(
    val id_port: Int,
    val latitude: Double,
    val longitude: Double,
    val nom: String,
    val url: String
)
